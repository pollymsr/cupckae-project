import mysql from 'mysql2/promise';

const cupcakes = [
  {
    name: "Dreamy Vanilla",
    description: "Cupcake de baunilha com cobertura de chantilly e confeitos coloridos",
    price: 500, // R$ 5.00 em centavos
    image: "vanilla"
  },
  {
    name: "Chocolate Magic",
    description: "Cupcake de chocolate com cobertura de ganache e cereja",
    price: 650,
    image: "chocolate"
  },
  {
    name: "Berry Fantasy",
    description: "Cupcake de morango com cobertura de cream cheese e frutas vermelhas",
    price: 700,
    image: "berry"
  },
  {
    name: "Rainbow Delight",
    description: "Cupcake colorido com cobertura de buttercream arco-íris",
    price: 800,
    image: "rainbow"
  },
  {
    name: "Lemon Bliss",
    description: "Cupcake de limão com cobertura de merengue",
    price: 600,
    image: "lemon"
  },
  {
    name: "Caramel Dream",
    description: "Cupcake de caramelo com cobertura de doce de leite",
    price: 750,
    image: "caramel"
  },
  {
    name: "Red Velvet Passion",
    description: "Cupcake Red Velvet com cobertura de cream cheese frosting",
    price: 850,
    image: "red-velvet"
  },
  {
    name: "Peanut Butter Joy",
    description: "Cupcake de chocolate com recheio de pasta de amendoim",
    price: 700,
    image: "peanut-butter"
  },
  {
    name: "Coconut Cloud",
    description: "Cupcake de coco com cobertura de marshmallow e coco ralado",
    price: 600,
    image: "coconut"
  },
  {
    name: "Coffee Kick",
    description: "Cupcake de café com cobertura de chocolate amargo",
    price: 750,
    image: "coffee"
  }
];

async function seedDatabase() {
  try {
    const connection = await mysql.createConnection(process.env.DATABASE_URL);
    
    // Check if cupcakes already exist
    const [rows] = await connection.execute('SELECT COUNT(*) as count FROM cupcakes');
    
    if (rows[0].count === 0) {
      console.log('Inserting cupcakes into database...');
      
      for (const cupcake of cupcakes) {
        await connection.execute(
          'INSERT INTO cupcakes (name, description, price, image) VALUES (?, ?, ?, ?)',
          [cupcake.name, cupcake.description, cupcake.price, cupcake.image]
        );
      }
      
      console.log(`✅ Successfully inserted ${cupcakes.length} cupcakes!`);
    } else {
      console.log('Cupcakes already exist in database. Skipping seed.');
    }
    
    await connection.end();
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
}

seedDatabase();
