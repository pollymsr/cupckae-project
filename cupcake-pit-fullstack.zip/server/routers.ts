import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { getAllCupcakes, getCupcakeById, createOrder, getOrderById, getUserOrders, createOrderItem, getOrderItems } from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  cupcakes: router({
    list: publicProcedure.query(async () => {
      return getAllCupcakes();
    }),
    get: publicProcedure
      .input((input: any) => input.id as number)
      .query(async ({ input }) => {
        return getCupcakeById(input);
      }),
  }),

  orders: router({
    create: protectedProcedure
      .input((input: any) => input as any)
      .mutation(async ({ input, ctx }) => {
        const orderResult = await createOrder({
          userId: ctx.user.id,
          status: "baking",
          total: input.total,
          paymentMethod: input.paymentMethod,
          customerName: input.customerName,
          customerEmail: input.customerEmail,
          customerAddress: input.customerAddress,
          customerCity: input.customerCity,
          customerZip: input.customerZip,
        });

        const orderId = (orderResult as any).insertId;

        for (const item of input.items) {
          await createOrderItem({
            orderId,
            cupcakeId: item.id,
            quantity: item.quantity,
            price: item.price,
          });
        }

        return { orderId, status: "baking" };
      }),
    
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserOrders(ctx.user.id);
    }),
    
    get: protectedProcedure
      .input((input: any) => input.id as number)
      .query(async ({ input, ctx }) => {
        const order = await getOrderById(input);
        
        if (!order || order.userId !== ctx.user.id) {
          throw new Error("Order not found or unauthorized");
        }
        
        const items = await getOrderItems(input);
        return { ...order, items };
      }),
  }),
});

export type AppRouter = typeof appRouter;
