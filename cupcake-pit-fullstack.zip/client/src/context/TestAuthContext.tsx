import React, { createContext, useContext, useState, useEffect } from "react";

export interface TestUser {
  id: number;
  name: string;
  email: string;
  openId: string;
}

interface TestAuthContextType {
  testUser: TestUser | null;
  isTestMode: boolean;
  loginAsTestUser: (user?: TestUser) => void;
  logoutTestUser: () => void;
}

const TestAuthContext = createContext<TestAuthContextType | undefined>(undefined);

const DEFAULT_TEST_USER: TestUser = {
  id: 1,
  name: "Pollyana Rocha",
  email: "pollyana@example.com",
  openId: "test-user-123",
};

export function TestAuthProvider({ children }: { children: React.ReactNode }) {
  const [testUser, setTestUser] = useState<TestUser | null>(null);

  // Load test user from localStorage on mount
  useEffect(() => {
    const savedTestUser = localStorage.getItem("test-auth-user");
    if (savedTestUser) {
      try {
        setTestUser(JSON.parse(savedTestUser));
      } catch (error) {
        console.error("Failed to load test user from localStorage:", error);
      }
    }
  }, []);

  const loginAsTestUser = (user?: TestUser) => {
    const userToSet = user || DEFAULT_TEST_USER;
    setTestUser(userToSet);
    localStorage.setItem("test-auth-user", JSON.stringify(userToSet));
  };

  const logoutTestUser = () => {
    setTestUser(null);
    localStorage.removeItem("test-auth-user");
  };

  return (
    <TestAuthContext.Provider
      value={{
        testUser,
        isTestMode: testUser !== null,
        loginAsTestUser,
        logoutTestUser,
      }}
    >
      {children}
    </TestAuthContext.Provider>
  );
}

export function useTestAuth() {
  const context = useContext(TestAuthContext);
  if (!context) {
    throw new Error("useTestAuth must be used within TestAuthProvider");
  }
  return context;
}
