import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Mail, User, MapPin, LogOut, Edit2, Check, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Profile() {
  const { user, isAuthenticated, logout } = useAuth();
  const { data: orders, isLoading: ordersLoading } = trpc.orders.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    name: user?.name || "",
    email: user?.email || "",
  });

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white">
        <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-sm border-b border-pink-100 shadow-sm">
          <div className="container mx-auto px-4 py-4 flex items-center">
            <h1 className="text-2xl font-bold">Meu Perfil</h1>
          </div>
        </header>

        <main className="container mx-auto px-4 py-12 text-center">
          <p className="text-xl text-gray-600 mb-6">Você precisa estar logado para acessar seu perfil</p>
          <Link href="/">
            <Button className="bg-gradient-to-r from-pink-500 to-pink-600">
              Voltar para Home
            </Button>
          </Link>
        </main>
      </div>
    );
  }

  const handleLogout = async () => {
    if (confirm("Tem certeza que deseja sair?")) {
      await logout();
      window.location.href = "/";
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      baking: "🧁 Preparando",
      "quality-check": "✨ Controle de Qualidade",
      "on-the-way": "🚚 A Caminho",
      delivered: "✅ Entregue",
    };
    return labels[status] || status;
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      baking: "bg-yellow-100 text-yellow-800",
      "quality-check": "bg-blue-100 text-blue-800",
      "on-the-way": "bg-purple-100 text-purple-800",
      delivered: "bg-green-100 text-green-800",
    };
    return colors[status] || "bg-gray-100 text-gray-800";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-sm border-b border-pink-100 shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">Meu Perfil</h1>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="text-red-600 border-red-200 hover:bg-red-50"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Sair
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 max-w-4xl">
        {/* User Information Card */}
        <Card className="mb-8 p-6">
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-br from-pink-400 to-purple-400 rounded-full w-16 h-16 flex items-center justify-center text-white text-2xl">
                <User className="h-8 w-8" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">{user.name || "Usuário"}</h2>
                <p className="text-gray-600">{user.email}</p>
              </div>
            </div>
            <Button
              onClick={() => setIsEditing(!isEditing)}
              variant="outline"
              className="gap-2"
            >
              <Edit2 className="h-4 w-4" />
              {isEditing ? "Cancelar" : "Editar"}
            </Button>
          </div>

          {isEditing ? (
            <div className="space-y-4 border-t pt-6">
              <div>
                <label className="block text-sm font-medium mb-2">Nome</label>
                <input
                  type="text"
                  value={editData.name}
                  onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Email</label>
                <input
                  type="email"
                  value={editData.email}
                  onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                />
              </div>
              <div className="flex gap-2 pt-4">
                <Button
                  onClick={() => {
                    alert("Informações atualizadas com sucesso!");
                    setIsEditing(false);
                  }}
                  className="bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700"
                >
                  <Check className="h-4 w-4 mr-2" />
                  Salvar
                </Button>
                <Button
                  onClick={() => setIsEditing(false)}
                  variant="outline"
                >
                  <X className="h-4 w-4 mr-2" />
                  Cancelar
                </Button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-6">
              <div className="flex items-center gap-3">
                <User className="h-5 w-5 text-pink-600" />
                <div>
                  <p className="text-sm text-gray-600">Nome</p>
                  <p className="font-medium">{user.name || "Não informado"}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-pink-600" />
                <div>
                  <p className="text-sm text-gray-600">Email</p>
                  <p className="font-medium">{user.email || "Não informado"}</p>
                </div>
              </div>
            </div>
          )}
        </Card>

        {/* Order History */}
        <div className="mb-8">
          <h3 className="text-2xl font-bold mb-6">Histórico de Pedidos</h3>

          {ordersLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-gray-200 rounded-lg h-32 animate-pulse" />
              ))}
            </div>
          ) : orders && orders.length > 0 ? (
            <div className="space-y-4">
              {orders.map((order: any) => (
                <Card key={order.id} className="p-6 hover:shadow-lg transition-shadow">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
                    <div>
                      <p className="text-sm text-gray-600">Pedido</p>
                      <p className="font-bold text-lg">#{order.id}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Data</p>
                      <p className="font-medium">
                        {new Date(order.createdAt).toLocaleDateString("pt-BR", {
                          day: "2-digit",
                          month: "2-digit",
                          year: "numeric",
                        })}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Total</p>
                      <p className="font-bold text-pink-600">R$ {(order.total / 100).toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Pagamento</p>
                      <p className="font-medium">
                        {order.paymentMethod === "credit" ? "💳 Cartão" : "📱 PIX"}
                      </p>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                        {getStatusLabel(order.status)}
                      </span>
                      <Link href={`/orders`}>
                        <Button variant="ghost" size="sm">
                          Ver Detalhes
                        </Button>
                      </Link>
                    </div>
                  </div>

                  {/* Order Items Preview */}
                  <div className="mt-4 pt-4 border-t">
                    <p className="text-sm text-gray-600 mb-2">Itens do Pedido</p>
                    <p className="text-sm text-gray-700">
                      {order.items?.length || 0} item(ns) - Entregue em {order.customerCity}
                    </p>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center">
              <p className="text-gray-600 mb-4">Você ainda não tem pedidos</p>
              <Link href="/menu">
                <Button className="bg-gradient-to-r from-pink-500 to-pink-600">
                  Fazer Primeiro Pedido
                </Button>
              </Link>
            </Card>
          )}
        </div>

        {/* Account Statistics */}
        <Card className="p-6 bg-gradient-to-r from-pink-50 to-purple-50">
          <h3 className="text-xl font-bold mb-4">Resumo da Conta</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-4">
              <p className="text-sm text-gray-600">Total de Pedidos</p>
              <p className="text-3xl font-bold text-pink-600">{orders?.length || 0}</p>
            </div>
            <div className="bg-white rounded-lg p-4">
              <p className="text-sm text-gray-600">Total Gasto</p>
              <p className="text-3xl font-bold text-pink-600">
                R$ {orders ? (orders.reduce((sum: number, order: any) => sum + order.total, 0) / 100).toFixed(2) : "0.00"}
              </p>
            </div>
            <div className="bg-white rounded-lg p-4">
              <p className="text-sm text-gray-600">Pedidos Entregues</p>
              <p className="text-3xl font-bold text-pink-600">
                {orders ? orders.filter((o: any) => o.status === "delivered").length : 0}
              </p>
            </div>
          </div>
        </Card>
      </main>
    </div>
  );
}
