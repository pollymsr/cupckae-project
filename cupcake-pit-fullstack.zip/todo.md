# Polly's Cupcakes - Full Stack TODO

## Features

### Back-end (API)
- [x] Criar tabela de cupcakes no banco de dados
- [x] Criar tabela de pedidos no banco de dados
- [x] Implementar endpoints para listar cupcakes
- [x] Implementar endpoints para criar pedidos
- [x] Implementar endpoints para listar pedidos do usuário
- [x] Implementar endpoints para rastrear pedido
- [x] Popular banco de dados com cupcakes

### Front-end (React)
- [x] Integrar listagem de cupcakes com API
- [x] Integrar carrinho com persistência em localStorage
- [x] Integrar checkout com validação e envio para API
- [x] Criar página de pedidos com histórico
- [x] Ajustar design e responsividade
- [x] Criar página Home com landing page
- [x] Criar página Menu com listagem de cupcakes

### Melhorias Gerais
- [x] Estrutura Full-Stack completa
- [x] Banco de dados MySQL com Drizzle ORM
- [x] API tRPC com autenticação
- [ ] Testes básicos de funcionalidade
- [ ] Documentação da API
- [ ] Deploy e hospedagem


### Perfil de Usuário (Nova Funcionalidade)
- [x] Criar página de perfil de usuário
- [x] Exibir informações pessoais do usuário
- [x] Mostrar histórico completo de pedidos
- [x] Adicionar opção de editar informações pessoais
- [x] Adicionar opção de logout
- [x] Integrar com API de usuário
- [x] Exibir resumo da conta (total de pedidos, total gasto, pedidos entregues)
- [x] Adicionar links de navegação para perfil em todas as páginas


## Bugs Reportados
- [x] Sistema de login não está funcionando (Corrigido com modo de teste)
